
/* main.js file for JS single page application */